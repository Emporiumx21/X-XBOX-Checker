import requests
import os
import random
import time
import ctypes
from datetime import datetime
import colorama
from colorama import Fore, Style
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

colorama.init(autoreset=True)

go_light_green = '\033[38;5;120m'

print_lock = threading.Lock()
write_lock = threading.Lock()

GREEN = Fore.LIGHTGREEN_EX
RED = Fore.LIGHTRED_EX
YELLOW = Fore.LIGHTYELLOW_EX
CYAN = Fore.LIGHTCYAN_EX
WHITE = Fore.LIGHTWHITE_EX
GREY = Fore.LIGHTBLACK_EX
RESET = Style.RESET_ALL

def timestamp():
    return f"{GREY}[{datetime.now().strftime('%I:%M:%S %p')}]"

def log(color, symbol, label, msg, **kwargs):
    extras = " ".join([f"{GREY}{k}={WHITE}{v}" for k, v in kwargs.items()])
    print(f"{timestamp()} {color}{symbol} {WHITE}{label}: {msg} {extras}{RESET}")

def fail(msg, **kw):     log(Fore.LIGHTRED_EX, "<!>", "Checked Code", msg, **kw)
def error(msg, **kw):    log(Fore.LIGHTRED_EX, "<!>", "Failed Code", msg, **kw)
def lock(msg, **kw):     log(Fore.YELLOW, "<->", "Checked Code", msg, **kw)
def success(msg, **kw):  log(go_light_green, "<+>", "Checked Code", msg, **kw)
def info(msg, **kw):     log(go_light_green, "<->", "Checked Code", msg, **kw)
def completed(msg, **kw):log(Fore.LIGHTCYAN_EX, "<INF>", "", msg, **kw)

def set_title(title):
    ctypes.windll.kernel32.SetConsoleTitleW(title)

def load_lines(filepath):
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]
        if not lines:
            raise Exception("File is empty")
        return lines
    except Exception as e:
        error(f"Failed to load {filepath}", reason=e)
        time.sleep(5)
        exit()

def write_result(path, code):
    with write_lock:
        with open(path, "a", encoding="utf-8") as f:
            f.write(code + "\n")

def format_proxy(proxy_line):
    if '@' in proxy_line:
        return { "http": f"http://{proxy_line}", "https": f"http://{proxy_line}" }
    parts = proxy_line.split(":")
    if len(parts) == 4:
        ip, port, user, pwd = parts
        return {
            "http": f"http://{user}:{pwd}@{ip}:{port}",
            "https": f"http://{user}:{pwd}@{ip}:{port}",
        }
    elif len(parts) == 2:
        return {
            "http": f"http://{proxy_line}",
            "https": f"http://{proxy_line}",
        }
    return None

def check_code(code, wlids, proxies):
    if len(code) < 18:
        fail(f"{code} is too short!", code=code)
        write_result("output/invalid.txt", code)
        return

    headers = {
        "accept": "application/json, text/javascript, */*; q=0.01",
        "authorization": random.choice(wlids),
        "origin": "https://www.microsoft.com",
        "referer": "https://www.microsoft.com/",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    }

    proxy_line = random.choice(proxies) if proxies else None
    proxy_dict = format_proxy(proxy_line) if proxy_line else None

    url = f"https://purchase.mp.microsoft.com/v7.0/tokenDescriptions/{code}?market=US&language=en-US&supportMultiAvailabilities=true"

    try:
        resp = requests.get(url, headers=headers, proxies=proxy_dict, timeout=10)

        if resp.status_code == 429:
            error("Ratelimit! Add more WLIDs or wait", code=code)
            time.sleep(10)
            return check_code(code, wlids, proxies)

        short_code = code[:17] + "-XXXXX-XXXXX"
        data = resp.json()

        if "tokenState" in data:
            state = data["tokenState"]
            if state == "Active":
                success("Valid", code=short_code)
                write_result("output/working.txt", code)
            elif state == "Redeemed":
                fail(f"Used Code", code=code)
                write_result("output/used.txt", code)
        elif data.get("code") == "NotFound":
            fail(f"Invalid Code", code=code)
            write_result("output/invalid.txt", code)
        elif data.get("code") == "Unauthorized":
            error("Invalid WLID detected!", code=code)
            time.sleep(5)
            exit()
        else:
            error("Unknown response", content=str(data), code=code)

    except Exception as e:
        error("Request failed", exception=str(e), proxy=proxy_line, code=code)

def main():
    os.system("cls" if os.name == "nt" else "clear")

    wlids = load_lines("input/WLID.txt")
    wlids = [line if line.startswith("WLID1.0=") else f'WLID1.0="{line}"' for line in wlids]

    codes = load_lines("input/codes.txt")
    proxies = load_lines("input/proxies.txt") if os.path.exists("input/proxies.txt") else []

    total = len(codes)
    threads = 2

    checked = 0
    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(check_code, code, wlids, proxies): code for code in codes}
        for future in as_completed(futures):
            checked += 1
            percent = int((checked / total) * 100)
            set_title(f"Xbox Code Checker | {checked}/{total} checked | {percent}% done")

    completed("Finished checking all codes!")
    time.sleep(30)

if __name__ == "__main__":
    main()
